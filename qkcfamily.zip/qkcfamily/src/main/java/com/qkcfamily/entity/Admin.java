package com.qkcfamily.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Admin {

	private String admin_id;
	private String admin_name;
	private String admin_pw;
	private String admin_email;
	private String created_at;
	
	
	
	
	
	
	
	
}
