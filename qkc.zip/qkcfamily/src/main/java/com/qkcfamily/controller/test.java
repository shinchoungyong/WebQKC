package com.qkcfamily.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class test {

	

	    @GetMapping("/test")
	    public String showHomePage() {
	        return "contentsManagement";  // /WEB-INF/views/home.jsp 파일을 반환
	    }
	    
	    @GetMapping("/testAdmin")
	    public String showHomePage1() {
	        return "Adm/Products"; 
	    }
	    
	    @GetMapping("/testAboutUs")
	    public String aboutUs() {
	        return "AboutUs/Export";
	    }
	    
	    @GetMapping("/example")
	    public String testexample() {
	        return "productManagement";  // /WEB-INF/views/aboutUs/aboutM.jsp 파일을 반환
	    }
	    
}
